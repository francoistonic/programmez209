# GotQuizz
Games of Thrones simple quizz in Xamarin Forms
