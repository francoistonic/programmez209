﻿namespace GotQuizz.Models
{
	public class QuizzQuestion
	{
		public string Question { get; set; }
		public bool Answer { get; set; }
	}
}
